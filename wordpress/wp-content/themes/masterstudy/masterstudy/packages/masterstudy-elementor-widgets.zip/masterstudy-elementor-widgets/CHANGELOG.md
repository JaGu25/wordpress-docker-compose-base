## 1.1.1
- Fixed post type name in patch interface 
- Fixed Sidebar widget

## 1.1.0
- Added Template Library with two headers
- Header parts added to Elementor 

## 1.0.1  
- Icon position settings fixed
- Elementor && WPBakery conflict fixed
- Title font weight fixed

## 1.0  
- Release.