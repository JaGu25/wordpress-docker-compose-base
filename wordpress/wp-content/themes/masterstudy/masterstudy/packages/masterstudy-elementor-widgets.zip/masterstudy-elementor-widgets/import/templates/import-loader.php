<div class="dialog-loading dialog-lightbox-loading" v-if="loading">
    <div id="elementor-template-library-loading">
        <div class="elementor-loader-wrapper">
            <div class="elementor-loader">
                <div class="elementor-loader-boxes">
                    <div class="elementor-loader-box"></div>
                    <div class="elementor-loader-box"></div>
                    <div class="elementor-loader-box"></div>
                    <div class="elementor-loader-box"></div>
                </div>
            </div>
            <div class="elementor-loading-title">Loading</div>
        </div>
    </div>
</div>