<div class="dialog-widget dialog-lightbox-widget dialog-type-buttons dialog-type-lightbox elementor-templates-modal" v-if="opened">

    <div class="dialog-widget-content dialog-lightbox-widget-content">

        <?php STM_Elementor_Template_Library::includeTemplate('import-header'); ?>

        <?php STM_Elementor_Template_Library::includeTemplate('import-content'); ?>

        <div class="dialog-buttons-wrapper dialog-lightbox-buttons-wrapper"></div>

    </div>
</div>