## Installation

```bash
npm install
gulp build
```