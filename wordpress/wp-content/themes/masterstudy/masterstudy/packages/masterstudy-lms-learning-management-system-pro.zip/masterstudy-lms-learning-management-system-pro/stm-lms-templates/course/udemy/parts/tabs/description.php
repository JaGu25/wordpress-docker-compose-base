<div class="stm_lms_course__content">
	<?php the_content(); ?>
</div>